package oclmetamodel;

/**
 * mCollectionItem object instance interface.
 */
public interface MCollectionItem extends oclmetamodel.MCollectionPart {
    /**
     * Returns the value of reference expression.
     * @return Value of reference expression.
     */
    public oclmetamodel.MExpression getExpression();
    /**
     * Sets the value of reference expression. See {@link #getExpression} for 
     * description on the reference.
     * @param newValue New value to be set.
     */
    public void setExpression(oclmetamodel.MExpression newValue);
}
