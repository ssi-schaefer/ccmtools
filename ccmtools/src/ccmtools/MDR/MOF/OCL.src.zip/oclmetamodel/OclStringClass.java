package oclmetamodel;

/**
 * OclString class proxy interface.
 */
public interface OclStringClass extends javax.jmi.reflect.RefClass {
    /**
     * The default factory operation used to create an instance object.
     * @return The created instance object.
     */
    public OclString createOclString();
    /**
     * Creates an instance object having attributes initialized by the passed 
     * values.
     * @param name 
     * @return The created instance object.
     */
    public OclString createOclString(java.lang.String name);
}
