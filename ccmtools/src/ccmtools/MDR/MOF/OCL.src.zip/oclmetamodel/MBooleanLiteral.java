package oclmetamodel;

/**
 * mBooleanLiteral object instance interface.
 */
public interface MBooleanLiteral extends oclmetamodel.MLiteralExpression {
    /**
     * Returns the value of attribute value.
     * @return Value of attribute value.
     */
    public boolean isValue();
    /**
     * Sets the value of value attribute. See {@link #isValue} for description 
     * on the attribute.
     * @param newValue New value to be set.
     */
    public void setValue(boolean newValue);
}
