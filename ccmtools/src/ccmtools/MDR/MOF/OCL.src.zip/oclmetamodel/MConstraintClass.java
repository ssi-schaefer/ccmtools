package oclmetamodel;

/**
 * mConstraint class proxy interface.
 */
public interface MConstraintClass extends javax.jmi.reflect.RefClass {
    /**
     * The default factory operation used to create an instance object.
     * @return The created instance object.
     */
    public MConstraint createMConstraint();
    /**
     * Creates an instance object having attributes initialized by the passed 
     * values.
     * @param name 
     * @param stereotype 
     * @return The created instance object.
     */
    public MConstraint createMConstraint(java.lang.String name, java.lang.String stereotype);
}
