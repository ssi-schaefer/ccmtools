package oclmetamodel;

/**
 * mCollectionRange object instance interface.
 */
public interface MCollectionRange extends oclmetamodel.MCollectionPart {
    /**
     * Returns the value of reference upperRange.
     * @return Value of reference upperRange.
     */
    public oclmetamodel.MExpression getUpperRange();
    /**
     * Sets the value of reference upperRange. See {@link #getUpperRange} for 
     * description on the reference.
     * @param newValue New value to be set.
     */
    public void setUpperRange(oclmetamodel.MExpression newValue);
    /**
     * Returns the value of reference lowerRange.
     * @return Value of reference lowerRange.
     */
    public oclmetamodel.MExpression getLowerRange();
    /**
     * Sets the value of reference lowerRange. See {@link #getLowerRange} for 
     * description on the reference.
     * @param newValue New value to be set.
     */
    public void setLowerRange(oclmetamodel.MExpression newValue);
}
