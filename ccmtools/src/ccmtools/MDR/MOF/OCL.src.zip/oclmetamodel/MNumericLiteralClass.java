package oclmetamodel;

/**
 * mNumericLiteral class proxy interface.
 */
public interface MNumericLiteralClass extends javax.jmi.reflect.RefClass {
}
