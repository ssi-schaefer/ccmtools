package oclmetamodel;

/**
 * mCollectionPart class proxy interface.
 */
public interface MCollectionPartClass extends javax.jmi.reflect.RefClass {
}
