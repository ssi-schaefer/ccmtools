package oclmetamodel;

/**
 * OclSequence object instance interface.
 */
public interface OclSequence extends oclmetamodel.OclCollection {
}
