package oclmetamodel;

/**
 * OclCollection class proxy interface.
 */
public interface OclCollectionClass extends javax.jmi.reflect.RefClass {
    /**
     * The default factory operation used to create an instance object.
     * @return The created instance object.
     */
    public OclCollection createOclCollection();
    /**
     * Creates an instance object having attributes initialized by the passed 
     * values.
     * @param name 
     * @param alias 
     * @return The created instance object.
     */
    public OclCollection createOclCollection(java.lang.String name, java.lang.String alias);
}
