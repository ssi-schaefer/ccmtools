package oclmetamodel;

/**
 * mCollectionLiteral object instance interface.
 */
public interface MCollectionLiteral extends oclmetamodel.MLiteralExpression {
    /**
     * Returns the value of attribute kind.
     * @return Value of attribute kind.
     */
    public java.lang.String getKind();
    /**
     * Sets the value of kind attribute. See {@link #getKind} for description 
     * on the attribute.
     * @param newValue New value to be set.
     */
    public void setKind(java.lang.String newValue);
    /**
     * Returns the value of reference items.
     * @return Value of reference items.
     */
    public java.util.List getItems();
}
