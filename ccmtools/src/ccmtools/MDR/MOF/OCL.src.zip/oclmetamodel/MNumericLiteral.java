package oclmetamodel;

/**
 * mNumericLiteral object instance interface.
 */
public interface MNumericLiteral extends oclmetamodel.MLiteralExpression {
    /**
     * Returns the value of attribute text.
     * @return Value of attribute text.
     */
    public java.lang.String getText();
    /**
     * Sets the value of text attribute. See {@link #getText} for description 
     * on the attribute.
     * @param newValue New value to be set.
     */
    public void setText(java.lang.String newValue);
}
