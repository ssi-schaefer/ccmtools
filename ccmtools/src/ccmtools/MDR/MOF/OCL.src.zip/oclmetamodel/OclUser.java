package oclmetamodel;

/**
 * OclUser object instance interface.
 */
public interface OclUser extends oclmetamodel.OclType {
}
