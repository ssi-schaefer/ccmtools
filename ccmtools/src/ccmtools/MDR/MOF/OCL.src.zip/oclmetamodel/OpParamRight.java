package oclmetamodel;

/**
 * OpParamRight association proxy interface.
 */
public interface OpParamRight extends javax.jmi.reflect.RefAssociation {
    /**
     * Queries whether a link currently exists between a given pair of instance 
     * objects in the associations link set.
     * @param opExpr Value of the first association end.
     * @param rightParameter Value of the second association end.
     * @return Returns true if the queried link exists.
     */
    public boolean exists(oclmetamodel.MOperationExpression opExpr, oclmetamodel.MExpression rightParameter);
    /**
     * Queries the instance objects that are related to a particular instance 
     * object by a link in the current associations link set.
     * @param opExpr Required value of the first association end.
     * @return Collection of related objects.
     */
    public java.util.Collection getOpExpr(oclmetamodel.MExpression rightParameter);
    /**
     * Queries the instance object that is related to a particular instance object 
     * by a link in the current associations link set.
     * @param rightParameter Required value of the second association end.
     * @return Related object or <code>null</code> if none exists.
     */
    public oclmetamodel.MExpression getRightParameter(oclmetamodel.MOperationExpression opExpr);
    /**
     * Creates a link between the pair of instance objects in the associations 
     * link set.
     * @param opExpr Value of the first association end.
     * @param rightParameter Value of the second association end.
     */
    public boolean add(oclmetamodel.MOperationExpression opExpr, oclmetamodel.MExpression rightParameter);
    /**
     * Removes a link between a pair of instance objects in the current associations 
     * link set.
     * @param opExpr Value of the first association end.
     * @param rightParameter Value of the second association end.
     */
    public boolean remove(oclmetamodel.MOperationExpression opExpr, oclmetamodel.MExpression rightParameter);
}
