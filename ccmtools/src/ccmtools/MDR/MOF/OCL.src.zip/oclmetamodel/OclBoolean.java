package oclmetamodel;

/**
 * OclBoolean object instance interface.
 */
public interface OclBoolean extends oclmetamodel.OclAny {
}
