package oclmetamodel;

/**
 * OCL metamodel package interface.
 */
public interface OclMetamodelPackage extends javax.jmi.reflect.RefPackage {
    /**
     * Returns OclEnumeration class proxy object.
     * @return OclEnumeration class proxy object.
     */
    public oclmetamodel.OclEnumerationClass getOclEnumeration();
    /**
     * Returns OclCollection class proxy object.
     * @return OclCollection class proxy object.
     */
    public oclmetamodel.OclCollectionClass getOclCollection();
    /**
     * Returns OclBag class proxy object.
     * @return OclBag class proxy object.
     */
    public oclmetamodel.OclBagClass getOclBag();
    /**
     * Returns OclSequence class proxy object.
     * @return OclSequence class proxy object.
     */
    public oclmetamodel.OclSequenceClass getOclSequence();
    /**
     * Returns OclSet class proxy object.
     * @return OclSet class proxy object.
     */
    public oclmetamodel.OclSetClass getOclSet();
    /**
     * Returns OclUser class proxy object.
     * @return OclUser class proxy object.
     */
    public oclmetamodel.OclUserClass getOclUser();
    /**
     * Returns OclVoid class proxy object.
     * @return OclVoid class proxy object.
     */
    public oclmetamodel.OclVoidClass getOclVoid();
    /**
     * Returns OclString class proxy object.
     * @return OclString class proxy object.
     */
    public oclmetamodel.OclStringClass getOclString();
    /**
     * Returns OclBoolean class proxy object.
     * @return OclBoolean class proxy object.
     */
    public oclmetamodel.OclBooleanClass getOclBoolean();
    /**
     * Returns OclInteger class proxy object.
     * @return OclInteger class proxy object.
     */
    public oclmetamodel.OclIntegerClass getOclInteger();
    /**
     * Returns OclReal class proxy object.
     * @return OclReal class proxy object.
     */
    public oclmetamodel.OclRealClass getOclReal();
    /**
     * Returns OclAny class proxy object.
     * @return OclAny class proxy object.
     */
    public oclmetamodel.OclAnyClass getOclAny();
    /**
     * Returns OclType class proxy object.
     * @return OclType class proxy object.
     */
    public oclmetamodel.OclTypeClass getOclType();
    /**
     * Returns MName class proxy object.
     * @return MName class proxy object.
     */
    public oclmetamodel.MNameClass getMName();
    /**
     * Returns MIfExpression class proxy object.
     * @return MIfExpression class proxy object.
     */
    public oclmetamodel.MIfExpressionClass getMIfExpression();
    /**
     * Returns MCollectionRange class proxy object.
     * @return MCollectionRange class proxy object.
     */
    public oclmetamodel.MCollectionRangeClass getMCollectionRange();
    /**
     * Returns MCollectionItem class proxy object.
     * @return MCollectionItem class proxy object.
     */
    public oclmetamodel.MCollectionItemClass getMCollectionItem();
    /**
     * Returns MCollectionPart class proxy object.
     * @return MCollectionPart class proxy object.
     */
    public oclmetamodel.MCollectionPartClass getMCollectionPart();
    /**
     * Returns MIntegerLiteral class proxy object.
     * @return MIntegerLiteral class proxy object.
     */
    public oclmetamodel.MIntegerLiteralClass getMIntegerLiteral();
    /**
     * Returns MRealLiteral class proxy object.
     * @return MRealLiteral class proxy object.
     */
    public oclmetamodel.MRealLiteralClass getMRealLiteral();
    /**
     * Returns MEnumLiteral class proxy object.
     * @return MEnumLiteral class proxy object.
     */
    public oclmetamodel.MEnumLiteralClass getMEnumLiteral();
    /**
     * Returns MBooleanLiteral class proxy object.
     * @return MBooleanLiteral class proxy object.
     */
    public oclmetamodel.MBooleanLiteralClass getMBooleanLiteral();
    /**
     * Returns MNumericLiteral class proxy object.
     * @return MNumericLiteral class proxy object.
     */
    public oclmetamodel.MNumericLiteralClass getMNumericLiteral();
    /**
     * Returns MStringLiteral class proxy object.
     * @return MStringLiteral class proxy object.
     */
    public oclmetamodel.MStringLiteralClass getMStringLiteral();
    /**
     * Returns MCollectionLiteral class proxy object.
     * @return MCollectionLiteral class proxy object.
     */
    public oclmetamodel.MCollectionLiteralClass getMCollectionLiteral();
    /**
     * Returns MLiteralExpression class proxy object.
     * @return MLiteralExpression class proxy object.
     */
    public oclmetamodel.MLiteralExpressionClass getMLiteralExpression();
    /**
     * Returns MDeclarator class proxy object.
     * @return MDeclarator class proxy object.
     */
    public oclmetamodel.MDeclaratorClass getMDeclarator();
    /**
     * Returns MPropertyCallParameters class proxy object.
     * @return MPropertyCallParameters class proxy object.
     */
    public oclmetamodel.MPropertyCallParametersClass getMPropertyCallParameters();
    /**
     * Returns MActualParameters class proxy object.
     * @return MActualParameters class proxy object.
     */
    public oclmetamodel.MActualParametersClass getMActualParameters();
    /**
     * Returns MPropertyCall class proxy object.
     * @return MPropertyCall class proxy object.
     */
    public oclmetamodel.MPropertyCallClass getMPropertyCall();
    /**
     * Returns MPostfixExpression class proxy object.
     * @return MPostfixExpression class proxy object.
     */
    public oclmetamodel.MPostfixExpressionClass getMPostfixExpression();
    /**
     * Returns MOperationExpression class proxy object.
     * @return MOperationExpression class proxy object.
     */
    public oclmetamodel.MOperationExpressionClass getMOperationExpression();
    /**
     * Returns MCollectionTypeSpec class proxy object.
     * @return MCollectionTypeSpec class proxy object.
     */
    public oclmetamodel.MCollectionTypeSpecClass getMCollectionTypeSpec();
    /**
     * Returns MSimpleTypeSpec class proxy object.
     * @return MSimpleTypeSpec class proxy object.
     */
    public oclmetamodel.MSimpleTypeSpecClass getMSimpleTypeSpec();
    /**
     * Returns MTypeSpecifier class proxy object.
     * @return MTypeSpecifier class proxy object.
     */
    public oclmetamodel.MTypeSpecifierClass getMTypeSpecifier();
    /**
     * Returns MFormalParameter class proxy object.
     * @return MFormalParameter class proxy object.
     */
    public oclmetamodel.MFormalParameterClass getMFormalParameter();
    /**
     * Returns MOperationContext class proxy object.
     * @return MOperationContext class proxy object.
     */
    public oclmetamodel.MOperationContextClass getMOperationContext();
    /**
     * Returns MClassifierContext class proxy object.
     * @return MClassifierContext class proxy object.
     */
    public oclmetamodel.MClassifierContextClass getMClassifierContext();
    /**
     * Returns MExpression class proxy object.
     * @return MExpression class proxy object.
     */
    public oclmetamodel.MExpressionClass getMExpression();
    /**
     * Returns MConstraintExpression class proxy object.
     * @return MConstraintExpression class proxy object.
     */
    public oclmetamodel.MConstraintExpressionClass getMConstraintExpression();
    /**
     * Returns MLetStatement class proxy object.
     * @return MLetStatement class proxy object.
     */
    public oclmetamodel.MLetStatementClass getMLetStatement();
    /**
     * Returns MConstraint class proxy object.
     * @return MConstraint class proxy object.
     */
    public oclmetamodel.MConstraintClass getMConstraint();
    /**
     * Returns MDefinition class proxy object.
     * @return MDefinition class proxy object.
     */
    public oclmetamodel.MDefinitionClass getMDefinition();
    /**
     * Returns MContext class proxy object.
     * @return MContext class proxy object.
     */
    public oclmetamodel.MContextClass getMContext();
    /**
     * Returns MPackage class proxy object.
     * @return MPackage class proxy object.
     */
    public oclmetamodel.MPackageClass getMPackage();
    /**
     * Returns MFile class proxy object.
     * @return MFile class proxy object.
     */
    public oclmetamodel.MFileClass getMFile();
    /**
     * Returns HasType association proxy object.
     * @return HasType association proxy object.
     */
    public oclmetamodel.HasType getHasType();
    /**
     * Returns CollectionType association proxy object.
     * @return CollectionType association proxy object.
     */
    public oclmetamodel.CollectionType getCollectionType();
    /**
     * Returns DeclaratorNames association proxy object.
     * @return DeclaratorNames association proxy object.
     */
    public oclmetamodel.DeclaratorNames getDeclaratorNames();
    /**
     * Returns EnumNames association proxy object.
     * @return EnumNames association proxy object.
     */
    public oclmetamodel.EnumNames getEnumNames();
    /**
     * Returns IfExprFalseExpr association proxy object.
     * @return IfExprFalseExpr association proxy object.
     */
    public oclmetamodel.IfExprFalseExpr getIfExprFalseExpr();
    /**
     * Returns IfExprTrueExpr association proxy object.
     * @return IfExprTrueExpr association proxy object.
     */
    public oclmetamodel.IfExprTrueExpr getIfExprTrueExpr();
    /**
     * Returns IfExprCondition association proxy object.
     * @return IfExprCondition association proxy object.
     */
    public oclmetamodel.IfExprCondition getIfExprCondition();
    /**
     * Returns CollectionUpperRangeExpression association proxy object.
     * @return CollectionUpperRangeExpression association proxy object.
     */
    public oclmetamodel.CollectionUpperRangeExpression getCollectionUpperRangeExpression();
    /**
     * Returns CollectionLowerRangeExpression association proxy object.
     * @return CollectionLowerRangeExpression association proxy object.
     */
    public oclmetamodel.CollectionLowerRangeExpression getCollectionLowerRangeExpression();
    /**
     * Returns CollectionItemExpression association proxy object.
     * @return CollectionItemExpression association proxy object.
     */
    public oclmetamodel.CollectionItemExpression getCollectionItemExpression();
    /**
     * Returns CollItems association proxy object.
     * @return CollItems association proxy object.
     */
    public oclmetamodel.CollItems getCollItems();
    /**
     * Returns DeclOptExpr association proxy object.
     * @return DeclOptExpr association proxy object.
     */
    public oclmetamodel.DeclOptExpr getDeclOptExpr();
    /**
     * Returns DeclOptType association proxy object.
     * @return DeclOptType association proxy object.
     */
    public oclmetamodel.DeclOptType getDeclOptType();
    /**
     * Returns DeclSimpleType association proxy object.
     * @return DeclSimpleType association proxy object.
     */
    public oclmetamodel.DeclSimpleType getDeclSimpleType();
    /**
     * Returns PropCallDecl association proxy object.
     * @return PropCallDecl association proxy object.
     */
    public oclmetamodel.PropCallDecl getPropCallDecl();
    /**
     * Returns PropCallActParams association proxy object.
     * @return PropCallActParams association proxy object.
     */
    public oclmetamodel.PropCallActParams getPropCallActParams();
    /**
     * Returns ActParamExpr association proxy object.
     * @return ActParamExpr association proxy object.
     */
    public oclmetamodel.ActParamExpr getActParamExpr();
    /**
     * Returns PropCallParams association proxy object.
     * @return PropCallParams association proxy object.
     */
    public oclmetamodel.PropCallParams getPropCallParams();
    /**
     * Returns PropertyParams association proxy object.
     * @return PropertyParams association proxy object.
     */
    public oclmetamodel.PropertyParams getPropertyParams();
    /**
     * Returns PostProperty association proxy object.
     * @return PostProperty association proxy object.
     */
    public oclmetamodel.PostProperty getPostProperty();
    /**
     * Returns PostExpr association proxy object.
     * @return PostExpr association proxy object.
     */
    public oclmetamodel.PostExpr getPostExpr();
    /**
     * Returns OpParamRight association proxy object.
     * @return OpParamRight association proxy object.
     */
    public oclmetamodel.OpParamRight getOpParamRight();
    /**
     * Returns OpParamLeft association proxy object.
     * @return OpParamLeft association proxy object.
     */
    public oclmetamodel.OpParamLeft getOpParamLeft();
    /**
     * Returns LetType association proxy object.
     * @return LetType association proxy object.
     */
    public oclmetamodel.LetType getLetType();
    /**
     * Returns LetParameters association proxy object.
     * @return LetParameters association proxy object.
     */
    public oclmetamodel.LetParameters getLetParameters();
    /**
     * Returns LetExpr association proxy object.
     * @return LetExpr association proxy object.
     */
    public oclmetamodel.LetExpr getLetExpr();
    /**
     * Returns ConstrExpr association proxy object.
     * @return ConstrExpr association proxy object.
     */
    public oclmetamodel.ConstrExpr getConstrExpr();
    /**
     * Returns HasStatement association proxy object.
     * @return HasStatement association proxy object.
     */
    public oclmetamodel.HasStatement getHasStatement();
    /**
     * Returns HasLetStmnt association proxy object.
     * @return HasLetStmnt association proxy object.
     */
    public oclmetamodel.HasLetStmnt getHasLetStmnt();
    /**
     * Returns HasConstrExpr association proxy object.
     * @return HasConstrExpr association proxy object.
     */
    public oclmetamodel.HasConstrExpr getHasConstrExpr();
    /**
     * Returns CollectionTypeName association proxy object.
     * @return CollectionTypeName association proxy object.
     */
    public oclmetamodel.CollectionTypeName getCollectionTypeName();
    /**
     * Returns FormalParameterType association proxy object.
     * @return FormalParameterType association proxy object.
     */
    public oclmetamodel.FormalParameterType getFormalParameterType();
    /**
     * Returns ContextTypeSpec association proxy object.
     * @return ContextTypeSpec association proxy object.
     */
    public oclmetamodel.ContextTypeSpec getContextTypeSpec();
    /**
     * Returns ContextParameters association proxy object.
     * @return ContextParameters association proxy object.
     */
    public oclmetamodel.ContextParameters getContextParameters();
    /**
     * Returns HasConstraints association proxy object.
     * @return HasConstraints association proxy object.
     */
    public oclmetamodel.HasConstraints getHasConstraints();
    /**
     * Returns HasDefinitions association proxy object.
     * @return HasDefinitions association proxy object.
     */
    public oclmetamodel.HasDefinitions getHasDefinitions();
    /**
     * Returns HasContexts association proxy object.
     * @return HasContexts association proxy object.
     */
    public oclmetamodel.HasContexts getHasContexts();
    /**
     * Returns HasPackages association proxy object.
     * @return HasPackages association proxy object.
     */
    public oclmetamodel.HasPackages getHasPackages();
}
