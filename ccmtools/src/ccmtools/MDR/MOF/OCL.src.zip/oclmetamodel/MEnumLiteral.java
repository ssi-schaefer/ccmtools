package oclmetamodel;

/**
 * mEnumLiteral object instance interface.
 */
public interface MEnumLiteral extends oclmetamodel.MLiteralExpression {
    /**
     * Returns the value of reference names.
     * @return Value of reference names.
     */
    public java.util.List getNames();
}
