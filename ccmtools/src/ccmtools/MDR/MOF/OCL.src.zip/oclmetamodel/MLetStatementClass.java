package oclmetamodel;

/**
 * mLetStatement class proxy interface.
 */
public interface MLetStatementClass extends javax.jmi.reflect.RefClass {
    /**
     * The default factory operation used to create an instance object.
     * @return The created instance object.
     */
    public MLetStatement createMLetStatement();
    /**
     * Creates an instance object having attributes initialized by the passed 
     * values.
     * @param name 
     * @return The created instance object.
     */
    public MLetStatement createMLetStatement(java.lang.String name);
}
