package oclmetamodel;

/**
 * mClassifierContext object instance interface.
 */
public interface MClassifierContext extends oclmetamodel.MContext {
    /**
     * Returns the value of attribute className.
     * @return Value of attribute className.
     */
    public java.lang.String getClassName();
    /**
     * Sets the value of className attribute. See {@link #getClassName} for description 
     * on the attribute.
     * @param newValue New value to be set.
     */
    public void setClassName(java.lang.String newValue);
    /**
     * Returns the value of attribute selfName.
     * @return Value of attribute selfName.
     */
    public java.lang.String getSelfName();
    /**
     * Sets the value of selfName attribute. See {@link #getSelfName} for description 
     * on the attribute.
     * @param newValue New value to be set.
     */
    public void setSelfName(java.lang.String newValue);
}
