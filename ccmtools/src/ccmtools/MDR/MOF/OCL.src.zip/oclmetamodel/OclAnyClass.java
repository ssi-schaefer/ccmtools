package oclmetamodel;

/**
 * OclAny class proxy interface.
 */
public interface OclAnyClass extends javax.jmi.reflect.RefClass {
}
