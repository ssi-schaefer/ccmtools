package oclmetamodel;

/**
 * ActParamExpr association proxy interface.
 */
public interface ActParamExpr extends javax.jmi.reflect.RefAssociation {
    /**
     * Queries whether a link currently exists between a given pair of instance 
     * objects in the associations link set.
     * @param parameters Value of the first association end.
     * @param expressions Value of the second association end.
     * @return Returns true if the queried link exists.
     */
    public boolean exists(oclmetamodel.MActualParameters parameters, oclmetamodel.MExpression expressions);
    /**
     * Queries the instance objects that are related to a particular instance 
     * object by a link in the current associations link set.
     * @param parameters Required value of the first association end.
     * @return Collection of related objects.
     */
    public java.util.Collection getParameters(oclmetamodel.MExpression expressions);
    /**
     * Queries the instance objects that are related to a particular instance 
     * object by a link in the current associations link set.
     * @param expressions Required value of the second association end.
     * @return List of related objects.
     */
    public java.util.List getExpressions(oclmetamodel.MActualParameters parameters);
    /**
     * Creates a link between the pair of instance objects in the associations 
     * link set.
     * @param parameters Value of the first association end.
     * @param expressions Value of the second association end.
     */
    public boolean add(oclmetamodel.MActualParameters parameters, oclmetamodel.MExpression expressions);
    /**
     * Removes a link between a pair of instance objects in the current associations 
     * link set.
     * @param parameters Value of the first association end.
     * @param expressions Value of the second association end.
     */
    public boolean remove(oclmetamodel.MActualParameters parameters, oclmetamodel.MExpression expressions);
}
