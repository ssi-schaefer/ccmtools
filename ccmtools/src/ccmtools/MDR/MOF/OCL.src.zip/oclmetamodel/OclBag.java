package oclmetamodel;

/**
 * OclBag object instance interface.
 */
public interface OclBag extends oclmetamodel.OclCollection {
}
