package oclmetamodel;

/**
 * mOperationExpression object instance interface.
 */
public interface MOperationExpression extends oclmetamodel.MExpression {
    /**
     * Returns the value of attribute operator.
     * @return Value of attribute operator.
     */
    public java.lang.String getOperator();
    /**
     * Sets the value of operator attribute. See {@link #getOperator} for description 
     * on the attribute.
     * @param newValue New value to be set.
     */
    public void setOperator(java.lang.String newValue);
    /**
     * Returns the value of reference rightParameter.
     * @return Value of reference rightParameter.
     */
    public oclmetamodel.MExpression getRightParameter();
    /**
     * Sets the value of reference rightParameter. See {@link #getRightParameter} 
     * for description on the reference.
     * @param newValue New value to be set.
     */
    public void setRightParameter(oclmetamodel.MExpression newValue);
    /**
     * Returns the value of reference leftParameter.
     * @return Value of reference leftParameter.
     */
    public oclmetamodel.MExpression getLeftParameter();
    /**
     * Sets the value of reference leftParameter. See {@link #getLeftParameter} 
     * for description on the reference.
     * @param newValue New value to be set.
     */
    public void setLeftParameter(oclmetamodel.MExpression newValue);
}
