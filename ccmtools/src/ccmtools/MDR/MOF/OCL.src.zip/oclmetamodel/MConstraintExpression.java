package oclmetamodel;

/**
 * mConstraintExpression object instance interface.
 */
public interface MConstraintExpression extends javax.jmi.reflect.RefObject {
    /**
     * Returns the value of reference expression.
     * @return Value of reference expression.
     */
    public oclmetamodel.MExpression getExpression();
    /**
     * Sets the value of reference expression. See {@link #getExpression} for 
     * description on the reference.
     * @param newValue New value to be set.
     */
    public void setExpression(oclmetamodel.MExpression newValue);
    /**
     * Returns the value of reference statements.
     * @return Value of reference statements.
     */
    public java.util.List getStatements();
}
