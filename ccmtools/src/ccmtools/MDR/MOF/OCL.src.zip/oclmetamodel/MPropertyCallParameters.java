package oclmetamodel;

/**
 * mPropertyCallParameters object instance interface.
 */
public interface MPropertyCallParameters extends javax.jmi.reflect.RefObject {
    /**
     * Returns the value of reference parameters.
     * @return Value of reference parameters.
     */
    public oclmetamodel.MActualParameters getParameters();
    /**
     * Sets the value of reference parameters. See {@link #getParameters} for 
     * description on the reference.
     * @param newValue New value to be set.
     */
    public void setParameters(oclmetamodel.MActualParameters newValue);
    /**
     * Returns the value of reference declarator.
     * @return Value of reference declarator.
     */
    public oclmetamodel.MDeclarator getDeclarator();
    /**
     * Sets the value of reference declarator. See {@link #getDeclarator} for 
     * description on the reference.
     * @param newValue New value to be set.
     */
    public void setDeclarator(oclmetamodel.MDeclarator newValue);
}
