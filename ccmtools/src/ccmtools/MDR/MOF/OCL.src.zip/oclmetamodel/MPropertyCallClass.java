package oclmetamodel;

/**
 * mPropertyCall class proxy interface.
 */
public interface MPropertyCallClass extends javax.jmi.reflect.RefClass {
    /**
     * The default factory operation used to create an instance object.
     * @return The created instance object.
     */
    public MPropertyCall createMPropertyCall();
    /**
     * Creates an instance object having attributes initialized by the passed 
     * values.
     * @param name 
     * @param previous 
     * @return The created instance object.
     */
    public MPropertyCall createMPropertyCall(java.lang.String name, boolean previous);
}
