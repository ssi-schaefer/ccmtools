package oclmetamodel;

/**
 * mTypeSpecifier class proxy interface.
 */
public interface MTypeSpecifierClass extends javax.jmi.reflect.RefClass {
}
