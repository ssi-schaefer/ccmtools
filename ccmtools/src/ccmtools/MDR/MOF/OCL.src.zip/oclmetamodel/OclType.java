package oclmetamodel;

/**
 * OclType object instance interface.
 */
public interface OclType extends javax.jmi.reflect.RefObject {
    /**
     * Returns the value of attribute name.
     * @return Value of attribute name.
     */
    public java.lang.String getName();
    /**
     * Sets the value of name attribute. See {@link #getName} for description 
     * on the attribute.
     * @param newValue New value to be set.
     */
    public void setName(java.lang.String newValue);
}
