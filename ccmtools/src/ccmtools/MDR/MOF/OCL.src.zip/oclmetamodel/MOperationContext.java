package oclmetamodel;

/**
 * mOperationContext object instance interface.
 */
public interface MOperationContext extends oclmetamodel.MContext {
    /**
     * Returns the value of attribute className.
     * @return Value of attribute className.
     */
    public java.lang.String getClassName();
    /**
     * Sets the value of className attribute. See {@link #getClassName} for description 
     * on the attribute.
     * @param newValue New value to be set.
     */
    public void setClassName(java.lang.String newValue);
    /**
     * Returns the value of attribute operationName.
     * @return Value of attribute operationName.
     */
    public java.lang.String getOperationName();
    /**
     * Sets the value of operationName attribute. See {@link #getOperationName} 
     * for description on the attribute.
     * @param newValue New value to be set.
     */
    public void setOperationName(java.lang.String newValue);
    /**
     * Returns the value of reference returnType.
     * @return Value of reference returnType.
     */
    public oclmetamodel.MTypeSpecifier getReturnType();
    /**
     * Sets the value of reference returnType. See {@link #getReturnType} for 
     * description on the reference.
     * @param newValue New value to be set.
     */
    public void setReturnType(oclmetamodel.MTypeSpecifier newValue);
    /**
     * Returns the value of reference parameters.
     * @return Value of reference parameters.
     */
    public java.util.List getParameters();
}
