package oclmetamodel;

/**
 * mEnumLiteral class proxy interface.
 */
public interface MEnumLiteralClass extends javax.jmi.reflect.RefClass {
    /**
     * The default factory operation used to create an instance object.
     * @return The created instance object.
     */
    public MEnumLiteral createMEnumLiteral();
}
