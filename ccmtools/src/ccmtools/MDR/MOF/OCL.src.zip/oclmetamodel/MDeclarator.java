package oclmetamodel;

/**
 * mDeclarator object instance interface.
 */
public interface MDeclarator extends javax.jmi.reflect.RefObject {
    /**
     * Returns the value of attribute optName.
     * @return Value of attribute optName.
     */
    public java.lang.String getOptName();
    /**
     * Sets the value of optName attribute. See {@link #getOptName} for description 
     * on the attribute.
     * @param newValue New value to be set.
     */
    public void setOptName(java.lang.String newValue);
    /**
     * Returns the value of reference optType.
     * @return Value of reference optType.
     */
    public oclmetamodel.MTypeSpecifier getOptType();
    /**
     * Sets the value of reference optType. See {@link #getOptType} for description 
     * on the reference.
     * @param newValue New value to be set.
     */
    public void setOptType(oclmetamodel.MTypeSpecifier newValue);
    /**
     * Returns the value of reference names.
     * @return Value of reference names.
     */
    public java.util.List getNames();
    /**
     * Returns the value of reference simpleType.
     * @return Value of reference simpleType.
     */
    public oclmetamodel.MSimpleTypeSpec getSimpleType();
    /**
     * Sets the value of reference simpleType. See {@link #getSimpleType} for 
     * description on the reference.
     * @param newValue New value to be set.
     */
    public void setSimpleType(oclmetamodel.MSimpleTypeSpec newValue);
    /**
     * Returns the value of reference optExpression.
     * @return Value of reference optExpression.
     */
    public oclmetamodel.MExpression getOptExpression();
    /**
     * Sets the value of reference optExpression. See {@link #getOptExpression} 
     * for description on the reference.
     * @param newValue New value to be set.
     */
    public void setOptExpression(oclmetamodel.MExpression newValue);
}
