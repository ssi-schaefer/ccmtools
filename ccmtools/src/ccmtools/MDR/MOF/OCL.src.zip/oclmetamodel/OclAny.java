package oclmetamodel;

/**
 * OclAny object instance interface.
 */
public interface OclAny extends oclmetamodel.OclType {
}
