package oclmetamodel;

/**
 * hasStatement association proxy interface.
 */
public interface HasStatement extends javax.jmi.reflect.RefAssociation {
    /**
     * Queries whether a link currently exists between a given pair of instance 
     * objects in the associations link set.
     * @param expression Value of the first association end.
     * @param statements Value of the second association end.
     * @return Returns true if the queried link exists.
     */
    public boolean exists(oclmetamodel.MConstraintExpression expression, oclmetamodel.MLetStatement statements);
    /**
     * Queries the instance objects that are related to a particular instance 
     * object by a link in the current associations link set.
     * @param expression Required value of the first association end.
     * @return Collection of related objects.
     */
    public java.util.Collection getExpression(oclmetamodel.MLetStatement statements);
    /**
     * Queries the instance objects that are related to a particular instance 
     * object by a link in the current associations link set.
     * @param statements Required value of the second association end.
     * @return List of related objects.
     */
    public java.util.List getStatements(oclmetamodel.MConstraintExpression expression);
    /**
     * Creates a link between the pair of instance objects in the associations 
     * link set.
     * @param expression Value of the first association end.
     * @param statements Value of the second association end.
     */
    public boolean add(oclmetamodel.MConstraintExpression expression, oclmetamodel.MLetStatement statements);
    /**
     * Removes a link between a pair of instance objects in the current associations 
     * link set.
     * @param expression Value of the first association end.
     * @param statements Value of the second association end.
     */
    public boolean remove(oclmetamodel.MConstraintExpression expression, oclmetamodel.MLetStatement statements);
}
