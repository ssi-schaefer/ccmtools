package oclmetamodel;

/**
 * mPropertyCallParameters class proxy interface.
 */
public interface MPropertyCallParametersClass extends javax.jmi.reflect.RefClass {
    /**
     * The default factory operation used to create an instance object.
     * @return The created instance object.
     */
    public MPropertyCallParameters createMPropertyCallParameters();
}
