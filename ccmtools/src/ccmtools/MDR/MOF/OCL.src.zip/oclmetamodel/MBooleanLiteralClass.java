package oclmetamodel;

/**
 * mBooleanLiteral class proxy interface.
 */
public interface MBooleanLiteralClass extends javax.jmi.reflect.RefClass {
    /**
     * The default factory operation used to create an instance object.
     * @return The created instance object.
     */
    public MBooleanLiteral createMBooleanLiteral();
    /**
     * Creates an instance object having attributes initialized by the passed 
     * values.
     * @param value 
     * @return The created instance object.
     */
    public MBooleanLiteral createMBooleanLiteral(boolean value);
}
