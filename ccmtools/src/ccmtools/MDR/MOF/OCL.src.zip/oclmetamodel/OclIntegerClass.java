package oclmetamodel;

/**
 * OclInteger class proxy interface.
 */
public interface OclIntegerClass extends javax.jmi.reflect.RefClass {
    /**
     * The default factory operation used to create an instance object.
     * @return The created instance object.
     */
    public OclInteger createOclInteger();
    /**
     * Creates an instance object having attributes initialized by the passed 
     * values.
     * @param name 
     * @return The created instance object.
     */
    public OclInteger createOclInteger(java.lang.String name);
}
