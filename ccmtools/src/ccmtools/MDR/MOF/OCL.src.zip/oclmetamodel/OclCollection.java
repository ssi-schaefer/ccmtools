package oclmetamodel;

/**
 * OclCollection object instance interface.
 */
public interface OclCollection extends oclmetamodel.OclType {
    /**
     * Returns the value of attribute alias.
     * @return Value of attribute alias.
     */
    public java.lang.String getAlias();
    /**
     * Sets the value of alias attribute. See {@link #getAlias} for description 
     * on the attribute.
     * @param newValue New value to be set.
     */
    public void setAlias(java.lang.String newValue);
    /**
     * Returns the value of reference type.
     * @return Value of reference type.
     */
    public oclmetamodel.OclType getType();
    /**
     * Sets the value of reference type. See {@link #getType} for description 
     * on the reference.
     * @param newValue New value to be set.
     */
    public void setType(oclmetamodel.OclType newValue);
}
