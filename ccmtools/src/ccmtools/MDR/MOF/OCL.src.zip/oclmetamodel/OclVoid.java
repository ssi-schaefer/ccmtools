package oclmetamodel;

/**
 * OclVoid object instance interface.
 */
public interface OclVoid extends oclmetamodel.OclType {
}
