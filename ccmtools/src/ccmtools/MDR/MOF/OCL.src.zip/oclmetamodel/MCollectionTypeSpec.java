package oclmetamodel;

/**
 * mCollectionTypeSpec object instance interface.
 */
public interface MCollectionTypeSpec extends oclmetamodel.MTypeSpecifier {
    /**
     * Returns the value of attribute kind.
     * @return Value of attribute kind.
     */
    public java.lang.String getKind();
    /**
     * Sets the value of kind attribute. See {@link #getKind} for description 
     * on the attribute.
     * @param newValue New value to be set.
     */
    public void setKind(java.lang.String newValue);
    /**
     * Returns the value of reference type.
     * @return Value of reference type.
     */
    public oclmetamodel.MSimpleTypeSpec getType();
    /**
     * Sets the value of reference type. See {@link #getType} for description 
     * on the reference.
     * @param newValue New value to be set.
     */
    public void setType(oclmetamodel.MSimpleTypeSpec newValue);
}
