package oclmetamodel;

/**
 * mStringLiteral class proxy interface.
 */
public interface MStringLiteralClass extends javax.jmi.reflect.RefClass {
    /**
     * The default factory operation used to create an instance object.
     * @return The created instance object.
     */
    public MStringLiteral createMStringLiteral();
    /**
     * Creates an instance object having attributes initialized by the passed 
     * values.
     * @param value 
     * @return The created instance object.
     */
    public MStringLiteral createMStringLiteral(java.lang.String value);
}
