package oclmetamodel;

/**
 * mRealLiteral class proxy interface.
 */
public interface MRealLiteralClass extends javax.jmi.reflect.RefClass {
    /**
     * The default factory operation used to create an instance object.
     * @return The created instance object.
     */
    public MRealLiteral createMRealLiteral();
    /**
     * Creates an instance object having attributes initialized by the passed 
     * values.
     * @param text 
     * @param value 
     * @return The created instance object.
     */
    public MRealLiteral createMRealLiteral(java.lang.String text, double value);
}
