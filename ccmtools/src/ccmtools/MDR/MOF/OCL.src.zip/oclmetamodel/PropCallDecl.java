package oclmetamodel;

/**
 * PropCallDecl association proxy interface.
 */
public interface PropCallDecl extends javax.jmi.reflect.RefAssociation {
    /**
     * Queries whether a link currently exists between a given pair of instance 
     * objects in the associations link set.
     * @param call Value of the first association end.
     * @param declarator Value of the second association end.
     * @return Returns true if the queried link exists.
     */
    public boolean exists(oclmetamodel.MPropertyCallParameters call, oclmetamodel.MDeclarator declarator);
    /**
     * Queries the instance objects that are related to a particular instance 
     * object by a link in the current associations link set.
     * @param call Required value of the first association end.
     * @return Collection of related objects.
     */
    public java.util.Collection getCall(oclmetamodel.MDeclarator declarator);
    /**
     * Queries the instance object that is related to a particular instance object 
     * by a link in the current associations link set.
     * @param declarator Required value of the second association end.
     * @return Related object or <code>null</code> if none exists.
     */
    public oclmetamodel.MDeclarator getDeclarator(oclmetamodel.MPropertyCallParameters call);
    /**
     * Creates a link between the pair of instance objects in the associations 
     * link set.
     * @param call Value of the first association end.
     * @param declarator Value of the second association end.
     */
    public boolean add(oclmetamodel.MPropertyCallParameters call, oclmetamodel.MDeclarator declarator);
    /**
     * Removes a link between a pair of instance objects in the current associations 
     * link set.
     * @param call Value of the first association end.
     * @param declarator Value of the second association end.
     */
    public boolean remove(oclmetamodel.MPropertyCallParameters call, oclmetamodel.MDeclarator declarator);
}
