package oclmetamodel;

/**
 * mFile object instance interface.
 */
public interface MFile extends javax.jmi.reflect.RefObject {
    /**
     * Returns the value of reference packages.
     * @return Value of reference packages.
     */
    public java.util.List getPackages();
}
