package oclmetamodel;

/**
 * OclBoolean class proxy interface.
 */
public interface OclBooleanClass extends javax.jmi.reflect.RefClass {
    /**
     * The default factory operation used to create an instance object.
     * @return The created instance object.
     */
    public OclBoolean createOclBoolean();
    /**
     * Creates an instance object having attributes initialized by the passed 
     * values.
     * @param name 
     * @return The created instance object.
     */
    public OclBoolean createOclBoolean(java.lang.String name);
}
