package oclmetamodel;

/**
 * mIfExpression class proxy interface.
 */
public interface MIfExpressionClass extends javax.jmi.reflect.RefClass {
    /**
     * The default factory operation used to create an instance object.
     * @return The created instance object.
     */
    public MIfExpression createMIfExpression();
}
