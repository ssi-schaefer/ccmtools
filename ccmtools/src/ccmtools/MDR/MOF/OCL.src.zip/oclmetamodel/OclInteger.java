package oclmetamodel;

/**
 * OclInteger object instance interface.
 */
public interface OclInteger extends oclmetamodel.OclReal {
}
