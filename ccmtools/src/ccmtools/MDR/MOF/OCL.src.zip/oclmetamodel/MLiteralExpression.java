package oclmetamodel;

/**
 * mLiteralExpression object instance interface.
 */
public interface MLiteralExpression extends oclmetamodel.MExpression {
}
