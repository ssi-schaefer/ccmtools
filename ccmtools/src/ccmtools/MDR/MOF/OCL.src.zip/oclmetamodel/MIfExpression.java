package oclmetamodel;

/**
 * mIfExpression object instance interface.
 */
public interface MIfExpression extends oclmetamodel.MExpression {
    /**
     * Returns the value of reference falseExpression.
     * @return Value of reference falseExpression.
     */
    public oclmetamodel.MExpression getFalseExpression();
    /**
     * Sets the value of reference falseExpression. See {@link #getFalseExpression} 
     * for description on the reference.
     * @param newValue New value to be set.
     */
    public void setFalseExpression(oclmetamodel.MExpression newValue);
    /**
     * Returns the value of reference trueExpression.
     * @return Value of reference trueExpression.
     */
    public oclmetamodel.MExpression getTrueExpression();
    /**
     * Sets the value of reference trueExpression. See {@link #getTrueExpression} 
     * for description on the reference.
     * @param newValue New value to be set.
     */
    public void setTrueExpression(oclmetamodel.MExpression newValue);
    /**
     * Returns the value of reference condition.
     * @return Value of reference condition.
     */
    public oclmetamodel.MExpression getCondition();
    /**
     * Sets the value of reference condition. See {@link #getCondition} for description 
     * on the reference.
     * @param newValue New value to be set.
     */
    public void setCondition(oclmetamodel.MExpression newValue);
}
