package oclmetamodel;

/**
 * OclBag class proxy interface.
 */
public interface OclBagClass extends javax.jmi.reflect.RefClass {
    /**
     * The default factory operation used to create an instance object.
     * @return The created instance object.
     */
    public OclBag createOclBag();
    /**
     * Creates an instance object having attributes initialized by the passed 
     * values.
     * @param name 
     * @param alias 
     * @return The created instance object.
     */
    public OclBag createOclBag(java.lang.String name, java.lang.String alias);
}
