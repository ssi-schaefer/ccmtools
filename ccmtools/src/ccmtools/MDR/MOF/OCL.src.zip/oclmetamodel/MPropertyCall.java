package oclmetamodel;

/**
 * mPropertyCall object instance interface.
 */
public interface MPropertyCall extends oclmetamodel.MExpression {
    /**
     * Returns the value of attribute name.
     * @return Value of attribute name.
     */
    public java.lang.String getName();
    /**
     * Sets the value of name attribute. See {@link #getName} for description 
     * on the attribute.
     * @param newValue New value to be set.
     */
    public void setName(java.lang.String newValue);
    /**
     * Returns the value of attribute previous.
     * @return Value of attribute previous.
     */
    public boolean isPrevious();
    /**
     * Sets the value of previous attribute. See {@link #isPrevious} for description 
     * on the attribute.
     * @param newValue New value to be set.
     */
    public void setPrevious(boolean newValue);
    /**
     * Returns the value of reference callParameters.
     * @return Value of reference callParameters.
     */
    public oclmetamodel.MPropertyCallParameters getCallParameters();
    /**
     * Sets the value of reference callParameters. See {@link #getCallParameters} 
     * for description on the reference.
     * @param newValue New value to be set.
     */
    public void setCallParameters(oclmetamodel.MPropertyCallParameters newValue);
    /**
     * Returns the value of reference qualifiers.
     * @return Value of reference qualifiers.
     */
    public oclmetamodel.MActualParameters getQualifiers();
    /**
     * Sets the value of reference qualifiers. See {@link #getQualifiers} for 
     * description on the reference.
     * @param newValue New value to be set.
     */
    public void setQualifiers(oclmetamodel.MActualParameters newValue);
}
