package oclmetamodel;

/**
 * mExpression object instance interface.
 */
public interface MExpression extends javax.jmi.reflect.RefObject {
    /**
     * Returns the value of reference oclType.
     * @return Value of reference oclType.
     */
    public oclmetamodel.OclType getOclType();
    /**
     * Sets the value of reference oclType. See {@link #getOclType} for description 
     * on the reference.
     * @param newValue New value to be set.
     */
    public void setOclType(oclmetamodel.OclType newValue);
}
