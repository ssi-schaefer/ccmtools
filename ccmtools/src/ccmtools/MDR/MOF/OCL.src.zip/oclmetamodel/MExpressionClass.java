package oclmetamodel;

/**
 * mExpression class proxy interface.
 */
public interface MExpressionClass extends javax.jmi.reflect.RefClass {
}
