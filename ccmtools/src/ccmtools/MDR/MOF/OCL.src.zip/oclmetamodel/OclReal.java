package oclmetamodel;

/**
 * OclReal object instance interface.
 */
public interface OclReal extends oclmetamodel.OclAny {
}
