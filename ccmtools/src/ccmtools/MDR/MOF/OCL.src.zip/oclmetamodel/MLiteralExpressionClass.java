package oclmetamodel;

/**
 * mLiteralExpression class proxy interface.
 */
public interface MLiteralExpressionClass extends javax.jmi.reflect.RefClass {
}
