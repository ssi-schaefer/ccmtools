package oclmetamodel;

/**
 * OclEnumeration object instance interface.
 */
public interface OclEnumeration extends oclmetamodel.OclAny {
}
