package oclmetamodel;

/**
 * OclType class proxy interface.
 */
public interface OclTypeClass extends javax.jmi.reflect.RefClass {
}
