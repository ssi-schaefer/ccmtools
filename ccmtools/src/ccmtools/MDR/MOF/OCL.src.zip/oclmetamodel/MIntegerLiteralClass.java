package oclmetamodel;

/**
 * mIntegerLiteral class proxy interface.
 */
public interface MIntegerLiteralClass extends javax.jmi.reflect.RefClass {
    /**
     * The default factory operation used to create an instance object.
     * @return The created instance object.
     */
    public MIntegerLiteral createMIntegerLiteral();
    /**
     * Creates an instance object having attributes initialized by the passed 
     * values.
     * @param text 
     * @param value 
     * @return The created instance object.
     */
    public MIntegerLiteral createMIntegerLiteral(java.lang.String text, int value);
}
