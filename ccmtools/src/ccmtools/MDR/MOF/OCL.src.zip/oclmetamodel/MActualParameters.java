package oclmetamodel;

/**
 * mActualParameters object instance interface.
 */
public interface MActualParameters extends javax.jmi.reflect.RefObject {
    /**
     * Returns the value of reference expressions.
     * @return Value of reference expressions.
     */
    public java.util.List getExpressions();
}
