package oclmetamodel;

/**
 * mConstraint object instance interface.
 */
public interface MConstraint extends javax.jmi.reflect.RefObject {
    /**
     * Returns the value of attribute name.
     * @return Value of attribute name.
     */
    public java.lang.String getName();
    /**
     * Sets the value of name attribute. See {@link #getName} for description 
     * on the attribute.
     * @param newValue New value to be set.
     */
    public void setName(java.lang.String newValue);
    /**
     * Returns the value of attribute stereotype.
     * @return Value of attribute stereotype.
     */
    public java.lang.String getStereotype();
    /**
     * Sets the value of stereotype attribute. See {@link #getStereotype} for 
     * description on the attribute.
     * @param newValue New value to be set.
     */
    public void setStereotype(java.lang.String newValue);
    /**
     * Returns the value of reference expression.
     * @return Value of reference expression.
     */
    public oclmetamodel.MConstraintExpression getExpression();
    /**
     * Sets the value of reference expression. See {@link #getExpression} for 
     * description on the reference.
     * @param newValue New value to be set.
     */
    public void setExpression(oclmetamodel.MConstraintExpression newValue);
}
