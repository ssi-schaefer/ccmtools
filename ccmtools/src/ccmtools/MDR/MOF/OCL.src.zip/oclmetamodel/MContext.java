package oclmetamodel;

/**
 * mContext object instance interface.
 */
public interface MContext extends javax.jmi.reflect.RefObject {
    /**
     * Returns the value of attribute identifier.
     * @return Value of attribute identifier.
     */
    public java.lang.String getIdentifier();
    /**
     * Sets the value of identifier attribute. See {@link #getIdentifier} for 
     * description on the attribute.
     * @param newValue New value to be set.
     */
    public void setIdentifier(java.lang.String newValue);
    /**
     * Returns the value of reference definitions.
     * @return Value of reference definitions.
     */
    public java.util.List getDefinitions();
    /**
     * Returns the value of reference constraints.
     * @return Value of reference constraints.
     */
    public java.util.Collection getConstraints();
}
