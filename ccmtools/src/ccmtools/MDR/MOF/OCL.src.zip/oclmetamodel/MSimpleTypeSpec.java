package oclmetamodel;

/**
 * mSimpleTypeSpec object instance interface.
 */
public interface MSimpleTypeSpec extends oclmetamodel.MTypeSpecifier {
    /**
     * Returns the value of attribute name.
     * @return Value of attribute name.
     */
    public java.lang.String getName();
    /**
     * Sets the value of name attribute. See {@link #getName} for description 
     * on the attribute.
     * @param newValue New value to be set.
     */
    public void setName(java.lang.String newValue);
}
