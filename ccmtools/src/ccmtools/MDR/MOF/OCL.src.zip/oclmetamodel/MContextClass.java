package oclmetamodel;

/**
 * mContext class proxy interface.
 */
public interface MContextClass extends javax.jmi.reflect.RefClass {
}
