package oclmetamodel;

/**
 * hasDefinitions association proxy interface.
 */
public interface HasDefinitions extends javax.jmi.reflect.RefAssociation {
    /**
     * Queries whether a link currently exists between a given pair of instance 
     * objects in the associations link set.
     * @param context Value of the first association end.
     * @param definitions Value of the second association end.
     * @return Returns true if the queried link exists.
     */
    public boolean exists(oclmetamodel.MContext context, oclmetamodel.MDefinition definitions);
    /**
     * Queries the instance objects that are related to a particular instance 
     * object by a link in the current associations link set.
     * @param context Required value of the first association end.
     * @return Collection of related objects.
     */
    public java.util.Collection getContext(oclmetamodel.MDefinition definitions);
    /**
     * Queries the instance objects that are related to a particular instance 
     * object by a link in the current associations link set.
     * @param definitions Required value of the second association end.
     * @return List of related objects.
     */
    public java.util.List getDefinitions(oclmetamodel.MContext context);
    /**
     * Creates a link between the pair of instance objects in the associations 
     * link set.
     * @param context Value of the first association end.
     * @param definitions Value of the second association end.
     */
    public boolean add(oclmetamodel.MContext context, oclmetamodel.MDefinition definitions);
    /**
     * Removes a link between a pair of instance objects in the current associations 
     * link set.
     * @param context Value of the first association end.
     * @param definitions Value of the second association end.
     */
    public boolean remove(oclmetamodel.MContext context, oclmetamodel.MDefinition definitions);
}
