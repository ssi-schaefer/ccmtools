package oclmetamodel;

/**
 * mName object instance interface.
 */
public interface MName extends javax.jmi.reflect.RefObject {
    /**
     * Returns the value of attribute value.
     * @return Value of attribute value.
     */
    public java.lang.String getValue();
    /**
     * Sets the value of value attribute. See {@link #getValue} for description 
     * on the attribute.
     * @param newValue New value to be set.
     */
    public void setValue(java.lang.String newValue);
}
