package oclmetamodel;

/**
 * mPostfixExpression object instance interface.
 */
public interface MPostfixExpression extends oclmetamodel.MExpression {
    /**
     * Returns the value of attribute collection.
     * @return Value of attribute collection.
     */
    public boolean isCollection();
    /**
     * Sets the value of collection attribute. See {@link #isCollection} for description 
     * on the attribute.
     * @param newValue New value to be set.
     */
    public void setCollection(boolean newValue);
    /**
     * Returns the value of reference expression.
     * @return Value of reference expression.
     */
    public oclmetamodel.MExpression getExpression();
    /**
     * Sets the value of reference expression. See {@link #getExpression} for 
     * description on the reference.
     * @param newValue New value to be set.
     */
    public void setExpression(oclmetamodel.MExpression newValue);
    /**
     * Returns the value of reference propertyCall.
     * @return Value of reference propertyCall.
     */
    public oclmetamodel.MPropertyCall getPropertyCall();
    /**
     * Sets the value of reference propertyCall. See {@link #getPropertyCall} 
     * for description on the reference.
     * @param newValue New value to be set.
     */
    public void setPropertyCall(oclmetamodel.MPropertyCall newValue);
}
