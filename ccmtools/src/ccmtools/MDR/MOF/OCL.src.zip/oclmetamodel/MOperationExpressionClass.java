package oclmetamodel;

/**
 * mOperationExpression class proxy interface.
 */
public interface MOperationExpressionClass extends javax.jmi.reflect.RefClass {
    /**
     * The default factory operation used to create an instance object.
     * @return The created instance object.
     */
    public MOperationExpression createMOperationExpression();
    /**
     * Creates an instance object having attributes initialized by the passed 
     * values.
     * @param operator 
     * @return The created instance object.
     */
    public MOperationExpression createMOperationExpression(java.lang.String operator);
}
