package oclmetamodel;

/**
 * OclString object instance interface.
 */
public interface OclString extends oclmetamodel.OclAny {
}
