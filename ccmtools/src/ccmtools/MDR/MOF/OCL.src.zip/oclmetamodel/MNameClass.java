package oclmetamodel;

/**
 * mName class proxy interface.
 */
public interface MNameClass extends javax.jmi.reflect.RefClass {
    /**
     * The default factory operation used to create an instance object.
     * @return The created instance object.
     */
    public MName createMName();
    /**
     * Creates an instance object having attributes initialized by the passed 
     * values.
     * @param value 
     * @return The created instance object.
     */
    public MName createMName(java.lang.String value);
}
