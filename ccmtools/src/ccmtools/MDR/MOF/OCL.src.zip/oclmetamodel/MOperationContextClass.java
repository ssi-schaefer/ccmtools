package oclmetamodel;

/**
 * mOperationContext class proxy interface.
 */
public interface MOperationContextClass extends javax.jmi.reflect.RefClass {
    /**
     * The default factory operation used to create an instance object.
     * @return The created instance object.
     */
    public MOperationContext createMOperationContext();
    /**
     * Creates an instance object having attributes initialized by the passed 
     * values.
     * @param identifier 
     * @param className 
     * @param operationName 
     * @return The created instance object.
     */
    public MOperationContext createMOperationContext(java.lang.String identifier, java.lang.String className, java.lang.String operationName);
}
