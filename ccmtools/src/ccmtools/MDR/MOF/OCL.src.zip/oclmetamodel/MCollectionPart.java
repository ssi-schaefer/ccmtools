package oclmetamodel;

/**
 * mCollectionPart object instance interface.
 */
public interface MCollectionPart extends javax.jmi.reflect.RefObject {
}
