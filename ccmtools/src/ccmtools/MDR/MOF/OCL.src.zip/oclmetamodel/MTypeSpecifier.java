package oclmetamodel;

/**
 * mTypeSpecifier object instance interface.
 */
public interface MTypeSpecifier extends javax.jmi.reflect.RefObject {
}
