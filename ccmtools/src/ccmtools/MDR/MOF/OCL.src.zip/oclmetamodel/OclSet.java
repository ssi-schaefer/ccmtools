package oclmetamodel;

/**
 * OclSet object instance interface.
 */
public interface OclSet extends oclmetamodel.OclCollection {
}
