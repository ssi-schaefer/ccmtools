package oclmetamodel;

/**
 * mCollectionTypeSpec class proxy interface.
 */
public interface MCollectionTypeSpecClass extends javax.jmi.reflect.RefClass {
    /**
     * The default factory operation used to create an instance object.
     * @return The created instance object.
     */
    public MCollectionTypeSpec createMCollectionTypeSpec();
    /**
     * Creates an instance object having attributes initialized by the passed 
     * values.
     * @param kind 
     * @return The created instance object.
     */
    public MCollectionTypeSpec createMCollectionTypeSpec(java.lang.String kind);
}
