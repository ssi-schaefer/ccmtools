package oclmetamodel;

/**
 * mClassifierContext class proxy interface.
 */
public interface MClassifierContextClass extends javax.jmi.reflect.RefClass {
    /**
     * The default factory operation used to create an instance object.
     * @return The created instance object.
     */
    public MClassifierContext createMClassifierContext();
    /**
     * Creates an instance object having attributes initialized by the passed 
     * values.
     * @param identifier 
     * @param className 
     * @param selfName 
     * @return The created instance object.
     */
    public MClassifierContext createMClassifierContext(java.lang.String identifier, java.lang.String className, java.lang.String selfName);
}
